
<div class="page-container">
	<div class="page-content-wrapper">
		<div class="page-content">
					<div class='pg' style="width: 500px; height: 700px; margin:0 auto; background-color:yellow;" >
					<div class='pg2' style="padding:20px;" >
					<h2><?php echo $page[0]->page_title; ?></h2>
					<p><?php echo $page[0]->content;?></p>
					</div>
					</div>
					</div>
					</div>
					</div>
					