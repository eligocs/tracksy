<div class="page-container">
	<div class="page-content-wrapper">
		<div class="page-content">
		<?php 
				$pid =get_promo_name($page[0]->promotion_id);
				$content = $page[0]->content;

		?>
					<div class='pg1' style="width: 500px; height: 700px; margin:0 auto; background-color:yellow;" ><img src="<?php echo base_url('site/images/promotions/').$content ?>"></div>			
		</div>
					</div>
					</div>
