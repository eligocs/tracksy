<?php 
$actual_link = 'https://'.$_SERVER['REQUEST_URI'];

 echo $actual_link; 
?>