<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<<<<<<< Updated upstream
ERROR - 2022-02-18 10:41:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\homepage\commingsoon.php 105
ERROR - 2022-02-18 10:41:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\homepage\commingsoon.php 105
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:39 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:44:39 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:44:39 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:44:39 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:44:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 10:44:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:44:56 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:44:56 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:44:56 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:44:56 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:44:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 10:44:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 10:45:47 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:45:47 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 10:45:47 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:45:47 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 10:45:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 10:45:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 10:56:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\tracksy\application\controllers\Homepage.php 67
ERROR - 2022-02-18 10:56:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\tracksy\application\controllers\Homepage.php 68
ERROR - 2022-02-18 10:56:43 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\tracksy\application\controllers\Homepage.php 67
ERROR - 2022-02-18 10:56:43 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\tracksy\application\controllers\Homepage.php 68
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6964
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6964
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6964
ERROR - 2022-02-18 11:13:46 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:13:46 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:13:46 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:13:46 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:13:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:13:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16543
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:23:40 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:23:40 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:23:40 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:23:40 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:23:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:23:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:21 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:31:21 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:31:21 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:31:21 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:31:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:31:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:31:29 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:31:29 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:31:29 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:31:29 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:31:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:31:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:17 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:17 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:17 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:17 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:33:17 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:22 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:22 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:22 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:22 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:33:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:35 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:35 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:35 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:35 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:33:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:33:39 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:39 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:33:39 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:39 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:33:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:33:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:24 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:24 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:24 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:24 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:34:24 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:27 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:27 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:27 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:27 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:34:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:34:47 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:47 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:34:47 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:47 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:34:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:34:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 225
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 11:35:00 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:35:00 --> Severity: Notice --> Trying to get property 'iti_close_status' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 278
ERROR - 2022-02-18 11:35:00 --> Severity: Notice --> Undefined variable: iti C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:35:00 --> Severity: Notice --> Trying to get property 'booking_benefits_meta' of non-object C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 438
ERROR - 2022-02-18 11:35:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\tracksy\application\views\accommodation\pdf.php 439
ERROR - 2022-02-18 11:35:00 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\tracksy\application\libraries\TCPDF\tcpdf.php 16542
=======
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 12:11:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 12:11:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
>>>>>>> Stashed changes
ERROR - 2022-02-18 12:57:18 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:57:18 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:57:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:57:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:57:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:57:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:18 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:18 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:20 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:20 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:20 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:20 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:58:20 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:58:20 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:59:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:59:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 12:59:19 --> Query error: Unknown column 'favicon' in 'field list' - Invalid query: SELECT `favicon`
FROM `homepage_setting`
 LIMIT 1
ERROR - 2022-02-18 12:59:19 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Global_model.php 301
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:49 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 13:00:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 13:00:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-18 13:10:15 --> Severity: Notice --> Undefined variable: is_gst_final C:\xampp\htdocs\trackv2\application\views\itineraries\view_iti.php 77
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-18 17:24:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-18 17:24:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
