<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:13:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:13:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 14:28:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 14:28:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-17 14:56:34 --> Query error: Unknown column 'www.paradise.org' in 'where clause' - Invalid query: SELECT *
FROM `hotels`
WHERE `id` = `www`.`paradise`.`org`
ERROR - 2022-02-17 14:56:34 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\trackv2\application\models\Hotel_model.php 96
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6962
ERROR - 2022-02-17 17:00:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 6963
ERROR - 2022-02-17 17:00:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\trackv2\application\libraries\TCPDF\tcpdf.php 16542
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:18:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:19:00 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
ERROR - 2022-02-17 17:22:59 --> Severity: Notice --> Undefined variable: selected C:\xampp\htdocs\trackv2\application\views\customers\leads_all_data.php 895
